 </section>
<section class="footeroption">
		<h2><?php echo "Developed By Nayem Howlader"; ?></h2>
	</section>
</div>
</body>
</html>